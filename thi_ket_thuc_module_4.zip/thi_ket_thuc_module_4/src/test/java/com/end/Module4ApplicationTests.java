package com.end;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Module4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
