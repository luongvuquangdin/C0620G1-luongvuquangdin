package com.end.repository;

import com.end.entity.TypeProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeProductRepository extends JpaRepository<TypeProduct,Integer> {
}
